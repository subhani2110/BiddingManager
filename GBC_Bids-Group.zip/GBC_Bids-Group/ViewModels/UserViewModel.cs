﻿using DataLayer.Entities;

namespace GBC_Bids_Group.ViewModels
{
    public class UserViewModel
    {
        public IEnumerable<User> Users { get; set; }
    }
}
